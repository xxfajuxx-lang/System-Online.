package de.fabi.systemonline

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("system_online", Context.MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private lateinit var sentenceInput: EditText
    private lateinit var enabledSwitch: Switch
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 25)
        window.navigationBarColor = Color.rgb(12, 12, 25)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(Color.rgb(12, 12, 25))
        }

        val title = TextView(this).apply {
            text = "SYSTEM ONLINE"
            textSize = 27f
            setTextColor(Color.rgb(175, 150, 255))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Deine Stimme beim Entsperren"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        root.addView(subtitle, matchWrap())

        enabledSwitch = Switch(this).apply {
            text = "Bei jeder Entsperrung sprechen"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
                status.text = if (checked) "Automatische Ansage ist aktiviert." else "Automatische Ansage ist ausgeschaltet."
            }
        }
        root.addView(enabledSwitch, matchWrap())

        val sentenceLabel = TextView(this).apply {
            text = "Dein Satz"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 26, 0, 8)
        }
        root.addView(sentenceLabel, matchWrap())

        sentenceInput = EditText(this).apply {
            setText(prefs.getString("sentence", "System online. Willkommen zurück."))
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "Schreibe deinen Satz"
            textSize = 17f
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(30, 29, 50))
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(sentenceInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val saveButton = Button(this).apply {
            text = "Satz speichern"
            setOnClickListener {
                val value = sentenceInput.text.toString().trim()
                if (value.isNotEmpty()) {
                    prefs.edit().putString("sentence", value).apply()
                    status.text = "Gespeichert."
                } else {
                    status.text = "Bitte zuerst einen Satz eingeben."
                }
            }
        }
        root.addView(saveButton, matchWrap())

        val testButton = Button(this).apply {
            text = "Stimme testen"
            setOnClickListener {
                val value = sentenceInput.text.toString().trim()
                if (value.isNotEmpty()) speakTest(value)
                else status.text = "Bitte zuerst einen Satz eingeben."
            }
        }
        root.addView(testButton, matchWrap())

        status = TextView(this).apply {
            text = if (enabledSwitch.isChecked) "Automatische Ansage ist aktiviert." else "Automatische Ansage ist ausgeschaltet."
            textSize = 14f
            setTextColor(Color.rgb(175, 150, 255))
            setPadding(0, 18, 0, 0)
        }
        root.addView(status, matchWrap())
        setContentView(root)
    }

    private fun speakTest(value: String) {
        tts?.shutdown()
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                val languageResult = tts?.setLanguage(Locale.GERMANY)
                tts?.setSpeechRate(0.9f)
                tts?.setPitch(0.85f)
                tts?.speak(value, TextToSpeech.QUEUE_FLUSH, null, "system_online_test")
                runOnUiThread { status.text = if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) "Deutsch fehlt eventuell bei den Sprachdaten." else "Sprachtest läuft." }
            } else {
                runOnUiThread { status.text = "Sprachausgabe konnte nicht gestartet werden." }
            }
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}
