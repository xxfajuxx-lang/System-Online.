package de.fabi.systemonline

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class UnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_USER_PRESENT) return

        val prefs = context.getSharedPreferences("system_online", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return

        val sentence = prefs.getString("sentence", "System online. Willkommen zurück.")?.trim().orEmpty()
        if (sentence.isBlank()) return

        val pending = goAsync()
        val engine = TextToSpeech(context.applicationContext) { result ->
            if (result == TextToSpeech.SUCCESS) {
                val tts = engineHolder
                try {
                    tts?.language = Locale.GERMANY
                    tts?.setSpeechRate(0.9f)
                    tts?.setPitch(0.85f)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            tts?.shutdown()
                            pending.finish()
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            tts?.shutdown()
                            pending.finish()
                        }
                        override fun onError(utteranceId: String?, errorCode: Int) {
                            tts?.shutdown()
                            pending.finish()
                        }
                    })
                    tts?.speak(sentence, TextToSpeech.QUEUE_FLUSH, Bundle(), "system_online_unlock")
                } catch (_: Exception) {
                    tts?.shutdown()
                    pending.finish()
                }
            } else {
                engineHolder?.shutdown()
                pending.finish()
            }
        }
        engineHolder = engine
    }

    companion object {
        @Volatile private var engineHolder: TextToSpeech? = null
    }
}
