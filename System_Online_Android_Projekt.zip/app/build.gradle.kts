plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.fabi.systemonline"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.fabi.systemonline"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
